public class Empresa {
    
    public String nomeEmpresa = "";
    public int identificador = 0; 

}
