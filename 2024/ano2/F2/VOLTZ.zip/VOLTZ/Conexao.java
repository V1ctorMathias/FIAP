import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class Conexao {

    public Connection conexao;

    public void conectarDb() {
        try {
            // Carregar manualmente o driver do Oracle
            Class.forName("oracle.jdbc.OracleDriver");

            // Configuração da conexão
            String url = "jdbc:oracle:thin:@oracle.fiap.com.br:1521:orcl";
            String usuario = "rm554099";
            String senha = "291103";

            // Tentar conexão
            conexao = DriverManager.getConnection(url, usuario, senha);

        } catch (ClassNotFoundException e) {
            System.err.println("Driver JDBC do Oracle não encontrado.");
            e.printStackTrace(); // Mostra detalhes do erro

        } catch (SQLException e) {
            System.err.println("Erro ao conectar: " + e.getMessage());
        }
    
    }

    public void cadastrar(String usuario, String senha) throws SQLException {
        this.conectarDb();

        Statement stm = this.conexao.createStatement();
        stm.executeUpdate("INSERT INTO Usuarios (Nome, Email, Senha) VALUES ('"+usuario+"', 'teste@hotmail.com', '"+senha+"')");
        stm.close();
    }

}
