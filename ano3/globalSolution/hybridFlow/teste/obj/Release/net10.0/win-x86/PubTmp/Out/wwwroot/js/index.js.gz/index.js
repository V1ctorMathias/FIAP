﻿console.log("Hello, World!");

form = document.querySelector("form")

botaoEnviar = document.querySelector("#enviar");

//botaoEnviar.location.href = ""

botaoEnviar.addEventListener('click', e => {

    //e.preventDefault();
});