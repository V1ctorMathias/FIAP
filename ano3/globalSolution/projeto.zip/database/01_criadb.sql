CREATE DATABASE HybridFlow;
GO

USE HybridFlow;
GO
